export default theme => ({
  contentStepper:{
    backgroundColor: 'rgba(249,249,249, 1)',
    display: 'flex',
    justifyContent: 'center'
  },
  mainContainer:{
    backgroundColor: 'rgba(249,249,249, 1)',
    display: 'flex',
    justifyContent: 'center',
  }
})
