export default theme => ({
  mainContainerListAlfred:{
    padding: '1%',
    display:'flex',
    flexDirection: 'column'
  }
})
