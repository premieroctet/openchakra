export default theme => ({
  avatarLetter: {
    height: 70,
    width: 70,
    margin: 'auto',
  },
})
