export default theme => ({
  infoWithPicsMainContainer:{
    display: 'flex',
    alignItems: 'center',
    padding: '5%'
  },
  infoWithPicsMarginRight:{
    marginRight: '5%'
  },
  infoWithPicsColorText:{
    color:'rgba(39,37,37,35%)'
  }
})
